﻿using System;
using System.Threading.Tasks;
using MyLibrary;

namespace Broker
{
    class Program
    {
          [System.Runtime.InteropServices.DllImport("user32.dll")]
          static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

          [System.Runtime.InteropServices.DllImport("Kernel32")]
          private static extern IntPtr GetConsoleWindow();

          const int SW_HIDE = 0;
          const int SW_SHOW = 5;
          static void Main(string[] args)
        {
               IntPtr hwnd;
               hwnd = GetConsoleWindow();
               ShowWindow(hwnd, SW_HIDE);
               
            Console.WriteLine("Broker");
            BrockerSocket socket = new BrockerSocket();
            socket.Start(Settings.Broker_Ip, Settings.Broker_Port);

            var worker = new Worker();
            Task.Factory.StartNew(worker.DoSendMessageWork, TaskCreationOptions.LongRunning);
            Console.ReadLine();

        }
    }
}
