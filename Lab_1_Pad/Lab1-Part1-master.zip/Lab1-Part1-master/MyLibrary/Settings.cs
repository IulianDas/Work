﻿namespace MyLibrary
{
    public class Settings
    {
        public static int Broker_Port = 69;
        public static string Broker_Ip = "127.0.0.1";
    }
}
