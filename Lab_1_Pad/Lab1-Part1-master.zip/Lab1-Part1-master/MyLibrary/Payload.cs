﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyLibrary
{
    public class Payload
    {
        public string Topic { get; set; }
        public string Message { get; set; }
    }
}
